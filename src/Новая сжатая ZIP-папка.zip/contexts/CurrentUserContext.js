import React from 'react';

export const currentUser = {};
export const CurrentUserContext = React.createContext();